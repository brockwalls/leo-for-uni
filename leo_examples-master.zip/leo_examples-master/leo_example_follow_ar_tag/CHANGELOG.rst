^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package leo_example_follow_ar_tag
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2022-11-22)
------------------
* Merge branch 'master' of github.com:LeoRover/leo_examples
* Change default marker size
* Contributors: Piotr Szlachcic

0.1.0 (2022-05-26)
------------------
* Comment out ar_track_alvar dependency
* leo_example_follow_ar_tag: follow_ar_tag.launch: fixed wrong package name in node tag
* Update follow_ar_tag example to work with the newer ROS API
* Move follow ar tag example to a separate package
* Contributors: Aleksander Szymański, Błażej Sowa
