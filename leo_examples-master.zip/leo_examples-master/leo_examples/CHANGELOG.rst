^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package leo_examples
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2022-11-22)
------------------
* Fix image conversion
* Change default marker size
* Contributors: Piotr Szlachcic

0.1.0 (2022-05-26)
------------------
* Add metapackage
* Contributors: Błażej Sowa
